
function showDetails(productName) {
    alert("You clicked on " + productName);
}
